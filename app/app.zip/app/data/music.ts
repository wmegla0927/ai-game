export const musicTracks = {
  // Using actual working 8-bit style music URLs from freesound.org and other sources
  // These are placeholder URLs - in a real app you'd host your own audio files
  intro: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  exploration: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav', 
  combat: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  safe_haven: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  death: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  victory: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
};