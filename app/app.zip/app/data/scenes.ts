import { Scene } from '@/types/game';

const scenes: Record<string, Scene> = {
  start: {
    id: 'start',
    text: "You awaken in a dimly lit chamber, the air thick with the scent of ancient dust and forgotten magic. A single torch flickers on the wall, casting long shadows across the stone floor. Before you stands a weathered wooden door, its surface etched with arcane symbols that seem to shift when you are not looking directly at them. Do you wish to open the door?",
    choices: {
      yes: {
        text: "Yes, I will open the door",
        nextSceneId: 'corridor',
      },
      no: {
        text: "No, I will examine the room more carefully first",
        nextSceneId: 'examine_room',
      },
      fate: [
        {
          text: "The door creaks open on its own, revealing a long corridor",
          nextSceneId: 'corridor',
        },
        {
          text: "As you hesitate, the symbols on the door glow with an eerie light, and you feel compelled to search the room",
          nextSceneId: 'examine_room',
        },
        {
          text: "The torch suddenly extinguishes, plunging you into darkness. When it reignites, you notice a hidden passage in the wall",
          nextSceneId: 'hidden_passage',
        }
      ],
    },
    music: 'intro',
  },
  
  examine_room: {
    id: 'examine_room',
    text: "You decide to search the chamber more thoroughly. In the corner, you discover a small wooden chest partially hidden beneath debris. It appears to be unlocked. Do you open it?",
    choices: {
      yes: {
        text: "Yes, I will open the chest",
        nextSceneId: 'chest_contents',
        effect: {
          type: 'addItem',
          value: 'rusty_dagger',
        },
      },
      no: {
        text: "No, it could be trapped. I will head for the door instead",
        nextSceneId: 'corridor',
      },
      fate: [
        {
          text: "As you reach for the chest, you notice a faint clicking sound. You manage to disarm a hidden needle trap and find something valuable inside",
          nextSceneId: 'chest_contents',
          effect: {
            type: 'addItem',
            value: 'silver_amulet',
          },
        },
        {
          text: "The chest suddenly transforms into a small, chittering mimic! You barely escape its snapping jaws",
          nextSceneId: 'corridor',
          effect: {
            type: 'damage',
            value: 10,
          },
        },
        {
          text: "The chest contains nothing but dust and disappointment",
          nextSceneId: 'corridor',
        }
      ],
    },
  },
  
  chest_contents: {
    id: 'chest_contents',
    text: "Inside the chest, you find a rusty dagger with strange runes etched along its blade. Despite its weathered appearance, it feels unnaturally sharp to the touch. You add it to your inventory. With nothing else of interest in the room, you turn your attention to the door. Do you proceed through it now?",
    choices: {
      yes: {
        text: "Yes, I will go through the door",
        nextSceneId: 'corridor',
      },
      no: {
        text: "No, I want to examine the dagger more closely first",
        nextSceneId: 'examine_dagger',
      },
      fate: [
        {
          text: "As you hesitate, the dagger pulses with a faint red glow, seeming to pull you toward the door",
          nextSceneId: 'corridor',
        },
        {
          text: "You notice additional markings on the dagger that reveal a clue about what lies ahead",
          nextSceneId: 'dagger_vision',
        },
        {
          text: "The door suddenly swings open on its own, revealing a dark corridor beyond",
          nextSceneId: 'corridor',
        }
      ],
    },
  },
  
  examine_dagger: {
    id: 'examine_dagger',
    text: "You study the dagger carefully. The runes begin to glow with a faint blue light, and you feel a strange connection to the weapon. Somehow, you understand that this blade is especially effective against demonic entities. With this knowledge, you feel more prepared to face whatever lies beyond the door. Do you proceed through it now?",
    choices: {
      yes: {
        text: "Yes, I will go through the door",
        nextSceneId: 'corridor',
      },
      no: {
        text: "No, I want to search the room one last time",
        nextSceneId: 'final_search',
      },
      fate: [
        {
          text: "The dagger suddenly feels ice-cold in your hand, and the door swings open on its own",
          nextSceneId: 'corridor',
        },
        {
          text: "You accidentally cut your finger on the blade, and a drop of your blood causes the runes to flare brightly",
          nextSceneId: 'blood_magic',
          effect: {
            type: 'damage',
            value: 5,
          },
        },
        {
          text: "You hear a scratching sound from beyond the door, growing louder by the second",
          nextSceneId: 'corridor',
        }
      ],
    },
  },
  
  corridor: {
    id: 'corridor',
    text: "You step through the doorway into a long, narrow corridor lit by sputtering torches. The walls are lined with faded tapestries depicting scenes of ancient battles between armored knights and grotesque demons. The air is noticeably colder here, and you can hear faint whispers that seem to come from nowhere and everywhere at once. The corridor extends ahead, but you also notice a side passage to your right. Do you continue straight ahead?",
    choices: {
      yes: {
        text: "Yes, I will continue straight down the corridor",
        nextSceneId: 'corridor_end',
      },
      no: {
        text: "No, I will take the side passage",
        nextSceneId: 'side_passage',
      },
      fate: [
        {
          text: "As you consider your options, you hear a distant scream from the side passage",
          nextSceneId: 'side_passage',
        },
        {
          text: "The torches along the main corridor suddenly burn brighter, as if encouraging you forward",
          nextSceneId: 'corridor_end',
        },
        {
          text: "A cold draft from the side passage extinguishes the nearest torch, plunging that route into darkness",
          nextSceneId: 'corridor_end',
        }
      ],
    },
  },
  
  side_passage: {
    id: 'side_passage',
    text: "The side passage is darker and narrower than the main corridor. The walls here are rough-hewn stone, lacking the tapestries and torches of the main path. After a short distance, the passage opens into a small chamber. In the center stands a stone pedestal with a glowing blue crystal hovering just above it. The crystal pulses with an inner light, almost like a heartbeat. Do you approach the crystal?",
    choices: {
      yes: {
        text: "Yes, I will approach the crystal",
        nextSceneId: 'crystal_chamber',
      },
      no: {
        text: "No, this seems suspicious. I will return to the main corridor",
        nextSceneId: 'return_to_corridor',
      },
      fate: [
        {
          text: "As you hesitate, the crystal's pulsing quickens, and it emits a soft, melodic hum that draws you closer",
          nextSceneId: 'crystal_chamber',
        },
        {
          text: "The ground trembles slightly, and small stones fall from the ceiling. This area does not seem stable",
          nextSceneId: 'return_to_corridor',
        },
        {
          text: "You notice ancient runes carved into the floor around the pedestal, forming a circle that glows faintly",
          nextSceneId: 'discover_runes',
        }
      ],
    },
  },
  
  crystal_chamber: {
    id: 'crystal_chamber',
    text: "As you approach the crystal, its pulsing light synchronizes with your heartbeat. You feel a strange connection to it, as if it has been waiting for you. The crystal hovers just within reach. Do you touch it?",
    choices: {
      yes: {
        text: "Yes, I will touch the crystal",
        nextSceneId: 'touch_crystal',
      },
      no: {
        text: "No, I will observe it more carefully without touching",
        nextSceneId: 'observe_crystal',
      },
      fate: [
        {
          text: "The crystal suddenly flies into your hand of its own accord, its light intensifying",
          nextSceneId: 'crystal_chooses_you',
        },
        {
          text: "As your hand nears the crystal, it emits a warning pulse of energy that pushes you back",
          nextSceneId: 'crystal_rejection',
          effect: {
            type: 'damage',
            value: 5,
          },
        },
        {
          text: "You trip on an uneven stone and accidentally knock into the pedestal, sending the crystal flying",
          nextSceneId: 'crystal_accident',
        }
      ],
    },
  },
  
  touch_crystal: {
    id: 'touch_crystal',
    text: "The moment your fingers touch the crystal, a surge of arcane energy flows through your body. Your mind fills with fragmented visions: a towering citadel of black stone, a throne room where shadows move of their own accord, and a crowned figure whose face is obscured by darkness. The crystal dims slightly but continues to pulse. You sense that it has bonded with you somehow. Do you take the crystal with you?",
    choices: {
      yes: {
        text: "Yes, I will take the crystal",
        nextSceneId: 'take_crystal',
        effect: {
          type: 'addItem',
          value: 'soul_crystal',
        },
      },
      no: {
        text: "No, these visions disturb me. I will leave it here",
        nextSceneId: 'leave_crystal',
      },
      fate: [
        {
          text: "The crystal suddenly shrinks to the size of a marble and flies into your pocket of its own accord",
          nextSceneId: 'crystal_chooses_you',
          effect: {
            type: 'addItem',
            value: 'soul_crystal',
          },
        },
        {
          text: "As you decide, the crystal flares brightly and splits in two. One half dissolves into your palm, while the other remains on the pedestal",
          nextSceneId: 'crystal_splits',
          effect: {
            type: 'addItem',
            value: 'crystal_shard',
          },
        },
        {
          text: "The crystal suddenly darkens and crumbles to dust before you can decide",
          nextSceneId: 'crystal_destruction',
        }
      ],
    },
  },
  
  inn_save_point: {
    id: 'inn_save_point',
    text: "You come across a small, welcoming inn nestled improbably within the dungeon walls. A sign swinging above the door reads 'The Restful Revenant.' Inside, a ghostly innkeeper nods at you from behind the bar. 'Rest here, traveler,' he says, 'and your journey thus far will be remembered.' The common room is warm and surprisingly cozy despite being underground. Do you wish to rest at the inn?",
    choices: {
      yes: {
        text: "Yes, I will rest at the inn",
        nextSceneId: 'after_inn_rest',
      },
      no: {
        text: "No, I will continue my journey without resting",
        nextSceneId: 'leave_inn',
      },
      fate: [
        {
          text: "As you hesitate, the innkeeper offers you a special brew 'on the house' that restores your vitality",
          nextSceneId: 'special_inn_brew',
          effect: {
            type: 'heal',
            value: 20,
          },
        },
        {
          text: "You notice other patrons at the inn - all adventurers like yourself, but something seems off about them",
          nextSceneId: 'suspicious_patrons',
        },
        {
          text: "Exhaustion suddenly overwhelms you, and you find yourself collapsing into a chair by the fire",
          nextSceneId: 'forced_rest',
        }
      ],
    },
    isSavePoint: true,
    savePointType: 'inn',
    music: 'safe_haven',
  },
  
  camp_save_point: {
    id: 'camp_save_point',
    text: "You discover a small alcove off the main path where someone has set up a rudimentary camp. A small fire burns in a stone-ringed pit, casting a warm glow on the surrounding walls. Beside it lies a bedroll and a small stack of supplies. There is no sign of the camp's owner, but the fire seems recently tended. This might be a good place to rest and gather your strength. Do you make use of the camp?",
    choices: {
      yes: {
        text: "Yes, I will rest at the camp",
        nextSceneId: 'after_camp_rest',
      },
      no: {
        text: "No, whoever made this camp might return. I should move on",
        nextSceneId: 'leave_camp',
      },
      fate: [
        {
          text: "As you consider the camp, you notice a small journal half-hidden by the bedroll",
          nextSceneId: 'camp_journal',
        },
        {
          text: "The fire suddenly flares up, revealing strange symbols carved into the surrounding stones",
          nextSceneId: 'camp_symbols',
        },
        {
          text: "You hear footsteps approaching from a nearby passage",
          nextSceneId: 'camp_owner_returns',
        }
      ],
    },
    isSavePoint: true,
    savePointType: 'camp',
    music: 'safe_haven',
  },
  
  bonfire_save_point: {
    id: 'bonfire_save_point',
    text: "In a circular chamber with a high domed ceiling, you find a peculiar bonfire burning with blue-green flames. Despite its unusual color, the fire gives off comforting warmth. Stone benches surround the fire in a circle, and you notice small offerings placed on some of them - coins, trinkets, and dried flowers. This appears to be some kind of shrine or resting place for travelers. Do you sit by the bonfire?",
    choices: {
      yes: {
        text: "Yes, I will rest by the bonfire",
        nextSceneId: 'after_bonfire_rest',
      },
      no: {
        text: "No, these strange flames make me uneasy. I will continue on",
        nextSceneId: 'leave_bonfire',
      },
      fate: [
        {
          text: "As you approach the bonfire, the flames shift to form a vaguely humanoid shape that gestures for you to sit",
          nextSceneId: 'fire_spirit',
        },
        {
          text: "You notice an inscription on one of the benches, partially worn away by time",
          nextSceneId: 'bonfire_inscription',
        },
        {
          text: "The bonfire suddenly flares higher, and you feel a strange pulling sensation",
          nextSceneId: 'bonfire_vision',
        }
      ],
    },
    isSavePoint: true,
    savePointType: 'bonfire',
    music: 'safe_haven',
  },
  
  keep_save_point: {
    id: 'keep_save_point',
    text: "You come upon a small fortified structure built into the dungeon wall - a miniature keep with stone walls and a single tower. The portcullis is raised, and torches burn in sconces on either side of the entrance. Above the gate, a banner displays a shield emblem you do not recognize. This appears to be an outpost of some kind, offering refuge in these dangerous depths. Do you enter the keep?",
    choices: {
      yes: {
        text: "Yes, I will enter the keep",
        nextSceneId: 'inside_keep',
      },
      no: {
        text: "No, it could be a trap. I will bypass it",
        nextSceneId: 'bypass_keep',
      },
      fate: [
        {
          text: "As you approach, a helmeted guard appears at the entrance and waves you inside urgently",
          nextSceneId: 'guard_welcome',
        },
        {
          text: "You notice that the torches at the entrance burn with an unnatural stillness, and no shadows are cast",
          nextSceneId: 'magical_keep',
        },
        {
          text: "A sudden tremor shakes the dungeon, and you dash inside the keep for safety",
          nextSceneId: 'tremor_refuge',
        }
      ],
    },
    isSavePoint: true,
    savePointType: 'keep',
    music: 'safe_haven',
  },
  
  death_scene: {
    id: 'death_scene',
    text: "Darkness closes in around you as your strength fails. Your vision blurs, and you feel a cold emptiness spreading through your body. As consciousness fades, you hear distant, mocking laughter. Then, nothing but void. But death is not the end in this realm. Your soul drifts through darkness until it finds its way back to the last sanctuary you visited. You awaken, your possessions gone but your memories intact. The journey continues...",
    isDeath: true,
    music: 'death',
  },
  
  hidden_passage: {
    id: 'hidden_passage',
    text: "The hidden passage is narrow and winding, forcing you to proceed in single file. The walls are damp, and occasional drops of water fall from the ceiling. After several minutes of careful navigation, you emerge into a small, circular chamber. In the center stands a weathered stone altar, and upon it rests an ancient tome bound in what appears to be human skin. Do you approach the altar?",
    choices: {
      yes: {
        text: "Yes, I will approach the altar",
        nextSceneId: 'altar_approach',
      },
      no: {
        text: "No, this looks ominous. I will try to find another way out",
        nextSceneId: 'find_exit',
      },
      fate: [
        {
          text: "As you hesitate, you hear whispers emanating from the tome, speaking in an unknown language",
          nextSceneId: 'whispering_tome',
        },
        {
          text: "The ground beneath the altar suddenly cracks, and the altar begins to sink into the floor",
          nextSceneId: 'sinking_altar',
        },
        {
          text: "A spectral figure materializes beside the altar, beckoning you forward",
          nextSceneId: 'spectral_librarian',
        }
      ],
    },
  },
  
  // Additional scenes to continue the adventure
  corridor_end: {
    id: 'corridor_end',
    text: "The corridor ends at a massive iron door adorned with demonic faces carved in relief. The faces seem to watch you as you approach, their eyes following your movement. A heavy iron ring serves as a handle, but you notice that touching it might require more courage than you currently possess. Do you attempt to open the door?",
    choices: {
      yes: {
        text: "Yes, I will open the door",
        nextSceneId: 'demon_door_open',
      },
      no: {
        text: "No, I will look for another way",
        nextSceneId: 'search_alternatives',
      },
      fate: [
        {
          text: "One of the carved faces suddenly speaks: 'Only the worthy may pass. Prove yourself!'",
          nextSceneId: 'demon_challenge',
        },
        {
          text: "The door swings open on its own, revealing a chamber filled with treasure... and danger",
          nextSceneId: 'treasure_chamber',
        },
        {
          text: "You hear heavy footsteps approaching from behind. Something is coming down the corridor!",
          nextSceneId: 'corridor_pursuit',
        }
      ],
    },
  },
  
  return_to_corridor: {
    id: 'return_to_corridor',
    text: "You decide discretion is the better part of valor and return to the main corridor. As you walk back, you hear a faint humming sound from the crystal chamber behind you, as if it is calling to you. But you press on, determined to find a safer path forward. The main corridor continues ahead, and you notice the air growing warmer. Do you continue forward?",
    choices: {
      yes: {
        text: "Yes, I will continue down the corridor",
        nextSceneId: 'corridor_end',
      },
      no: {
        text: "No, I will go back to the crystal chamber",
        nextSceneId: 'crystal_chamber',
      },
      fate: [
        {
          text: "A warm breeze carries the scent of food and safety from ahead",
          nextSceneId: 'inn_save_point',
        },
        {
          text: "You hear the crystal chamber collapse behind you with a thunderous crash",
          nextSceneId: 'corridor_end',
        },
        {
          text: "Strange shadows begin moving along the walls, independent of any light source",
          nextSceneId: 'shadow_encounter',
        }
      ],
    },
  },
};

export default scenes;