import { useEffect, useState } from 'react';
import { Platform } from 'react-native';

// Simple 8-bit style audio URLs (these are placeholder URLs)
// In a real app, you would host your own 8-bit music files
const musicTracks = {
  intro: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  exploration: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav', 
  combat: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  safe_haven: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  death: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
  victory: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
};

export function useAudio() {
  const [currentTrack, setCurrentTrack] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false); // Keep disabled for now

  useEffect(() => {
    // Audio is disabled to prevent errors in this demo
    // In a real app, you would implement proper audio handling here
    setAudioEnabled(false);
  }, []);

  const playTrack = async (trackName: keyof typeof musicTracks) => {
    // Audio playback disabled to prevent errors
    console.log(`Would play track: ${trackName}`);
    setCurrentTrack(trackName);
    setIsPlaying(true);
  };

  const stopTrack = async () => {
    console.log('Would stop current track');
    setIsPlaying(false);
    setCurrentTrack(null);
  };

  const pauseTrack = async () => {
    console.log('Would pause current track');
    setIsPlaying(false);
  };

  const resumeTrack = async () => {
    console.log('Would resume current track');
    setIsPlaying(true);
  };

  return {
    playTrack,
    stopTrack,
    pauseTrack,
    resumeTrack,
    isPlaying,
    currentTrack,
    audioEnabled,
  };
}