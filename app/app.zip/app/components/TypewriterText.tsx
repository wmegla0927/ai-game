import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, TouchableWithoutFeedback, View } from 'react-native';
import PixelText from './PixelText';

interface TypewriterTextProps {
  text: string;
  speed?: number;
  onComplete?: () => void;
  style?: any;
}

export default function TypewriterText({ 
  text, 
  speed = 30, 
  onComplete,
  style 
}: TypewriterTextProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [isSpeedUp, setIsSpeedUp] = useState(false);
  const index = useRef(0);
  const textRef = useRef(text);
  const completedRef = useRef(false);

  // Reset when text changes
  useEffect(() => {
    index.current = 0;
    setDisplayedText('');
    setIsComplete(false);
    setIsSpeedUp(false);
    completedRef.current = false;
    textRef.current = text;
  }, [text]);

  useEffect(() => {
    if (isComplete || completedRef.current) {
      if (!completedRef.current) {
        completedRef.current = true;
        onComplete?.();
      }
      return;
    }

    const currentSpeed = isSpeedUp ? 5 : speed;
    const timer = setTimeout(() => {
      if (index.current < textRef.current.length) {
        setDisplayedText(prev => prev + textRef.current.charAt(index.current));
        index.current += 1;
      } else {
        setIsComplete(true);
      }
    }, currentSpeed);

    return () => clearTimeout(timer);
  }, [displayedText, isComplete, onComplete, speed, isSpeedUp]);

  const handlePressIn = () => {
    setIsSpeedUp(true);
  };

  const handlePressOut = () => {
    setIsSpeedUp(false);
  };

  const handlePress = () => {
    // If text is complete, do nothing
    // If text is not complete, speed it up by completing it instantly
    if (!isComplete) {
      setDisplayedText(textRef.current);
      setIsComplete(true);
    }
  };

  return (
    <TouchableWithoutFeedback
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={handlePress}
    >
      <View>
        <PixelText style={[styles.text, style]}>
          {displayedText}
          {!isComplete && <PixelText style={styles.cursor}>_</PixelText>}
        </PixelText>
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  text: {
    lineHeight: 24,
  },
  cursor: {
    opacity: 1,
  },
});